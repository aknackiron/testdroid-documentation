package com.bitbar.testdroid.test.big;

import android.app.Activity;
import android.test.ActivityInstrumentationTestCase2;
import android.util.Log;

import com.bitbar.recorder.extensions.ExtSolo;
import com.bitbar.testdroid.test.annotations.Annotation1;
import com.bitbar.testdroid.test.annotations.Annotation2;

public class BitbarSampleApplicationActivityBigTest extends ActivityInstrumentationTestCase2<Activity> {

    private static final String LAUNCHER_ACTIVITY_CLASSNAME = "com.bitbar.testdroid.BitbarSampleApplicationActivity";
    private static Class<?> launchActivityClass;
    static {
        try {
            launchActivityClass = Class.forName(LAUNCHER_ACTIVITY_CLASSNAME);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    private ExtSolo solo; // ExtSolo is an extension of Robotium Solo that helps collecting better test execution data during test runs

    @SuppressWarnings("unchecked")
    public BitbarSampleApplicationActivityBigTest() {
        super("com.bitbar.testdroid", (Class<Activity>) launchActivityClass);
    }

    @Override
    public void setUp() throws Exception {
        super.setUp();
        solo = new ExtSolo(getInstrumentation(), getActivity(), this.getClass().getCanonicalName(), getName());
    }

    @Override
    public void tearDown() throws Exception {
        solo.finishOpenedActivities();
        solo.tearDown();
        super.tearDown();
    }

    @Annotation1
    public void test1() throws Exception {
        Log.d("TEST", String.format("Executing: %s#%s", this.getClass().getCanonicalName(), getName()));
    }
    
    @Annotation2
    public void test2() throws Exception {
        Log.d("TEST", String.format("Executing: %s#%s", this.getClass().getCanonicalName(), getName()));
    }
    
    @Annotation1
    public void test3() throws Exception {
        Log.d("TEST", String.format("Executing: %s#%s", this.getClass().getCanonicalName(), getName()));
    }
    
    @Annotation2
    public void test4() throws Exception {
        Log.d("TEST", String.format("Executing: %s#%s", this.getClass().getCanonicalName(), getName()));
    }
    
    @Annotation1
    public void test5() throws Exception {
        Log.d("TEST", String.format("Executing: %s#%s", this.getClass().getCanonicalName(), getName()));
    }
    
    @Annotation2
    public void test6() throws Exception {
        Log.d("TEST", String.format("Executing: %s#%s", this.getClass().getCanonicalName(), getName()));
    }
    
    @Annotation1
    public void test7() throws Exception {
        Log.d("TEST", String.format("Executing: %s#%s", this.getClass().getCanonicalName(), getName()));
    }
    
    @Annotation2
    public void test8() throws Exception {
        Log.d("TEST", String.format("Executing: %s#%s", this.getClass().getCanonicalName(), getName()));
    }
    
    @Annotation1
    public void test9() throws Exception {
        Log.d("TEST", String.format("Executing: %s#%s", this.getClass().getCanonicalName(), getName()));
    }
}
